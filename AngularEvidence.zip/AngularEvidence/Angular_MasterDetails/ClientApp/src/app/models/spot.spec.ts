import { Spot } from './spot';

describe('Spot', () => {
  it('should create an instance', () => {
    expect(new Spot()).toBeTruthy();
  });
});
