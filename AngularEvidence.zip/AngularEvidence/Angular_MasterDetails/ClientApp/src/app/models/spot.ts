export class Spot {
  constructor(
            public spotId? : number,
            public spotName? : string
  ){}
}
